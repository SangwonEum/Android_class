package com.example.btest.ch4;


import com.example.btest.R;

import android.app.Activity;
import android.os.Bundle;

public class NotiActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.noti_act);
    }
}
