package com.example.gtest.ch8;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gtest.R;

public class MyLocActivity1  extends Activity{
	private static final String TAG="MyLocActivity01";
	private TextView locationTextView;
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mylocation);
		
		locationTextView=(TextView) findViewById(R.id.location);
		
		LocationManager locationManager;
		LocationListener locationListener;
		locationManager=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
		
		for(String provider:locationManager.getAllProviders()){
			Log.d(TAG,provider);
		}
			
		locationListener=new LocationListener(){

			@Override
			public void onLocationChanged(Location location) {
				String message=String.format("���� :%f , �浵 : %f",location.getLatitude(),
																 location.getLongitude());
				Toast.makeText(MyLocActivity1.this,message,Toast.LENGTH_SHORT).show();
				locationTextView.setText(message);
				
			}

			@Override
			public void onProviderDisabled(String arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderEnabled(String arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
				// TODO Auto-generated method stub
				
			}
			
		};
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,locationListener);
		
	}

}
