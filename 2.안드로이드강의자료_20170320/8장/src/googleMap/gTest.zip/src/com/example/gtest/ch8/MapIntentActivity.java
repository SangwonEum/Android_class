package com.example.gtest.ch8;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.gtest.R;

public class MapIntentActivity extends Activity {
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map_intent);
	}
	
	public void map(View view){
		String intentString="geo:37.526779,127.027613";
		Uri geoUri=Uri.parse(intentString);
		Intent intent=new Intent(Intent.ACTION_VIEW,geoUri);
		startActivity(intent);
		
	}

}
