package com.example.gtest.ch8;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.app.ProgressDialog;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gtest.R;

public class MyLocActivity3  extends Activity{
	private TextView locTextView;
	ProgressDialog dialog;
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mylocation3);
		locTextView=(TextView)findViewById(R.id.address);
		
	}
	
	public void geocoder(View view){
		double latitude=37.526779;
		double longitude=127.028518;
		
		Locale.setDefault(Locale.KOREA);
		Geocoder geocoder=new Geocoder(getApplicationContext());
		try{
			List<Address> addressList=geocoder.getFromLocation(latitude, longitude, 3);
			
			for(Address address : addressList){
				String countryName=address.getCountryName();
				String placeName=address.getLocality();
				String bungi=address.getFeatureName();
				
				String message=String.format("[%s][%s][%s]",countryName,placeName,bungi);
				Log.d("TAG",message);
				Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
				locTextView.setText(message);
			}
		}catch(IOException e){
			
			e.printStackTrace();
		}
	}
	

}
