package androidbook.ch05.dialog;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class DialogSample02 extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final ProgressDialog progressDialog;
                progressDialog = new ProgressDialog(DialogSample02.this);
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.setMessage("��ø� ��ٷ��ּ���...");
                progressDialog.setCancelable(false);
                progressDialog.setIndeterminate(true);
                progressDialog.show();

                Thread t = new Thread() {
                    public void run() {
                        int tick = 0;
                        while (tick < 100) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                            }
                            tick++;
                            progressDialog.incrementProgressBy(1);
                        }
                    }
                };
                t.start();
            }
        });
    }
}
