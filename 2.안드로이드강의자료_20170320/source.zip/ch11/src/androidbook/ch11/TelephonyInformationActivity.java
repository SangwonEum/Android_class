package androidbook.ch11;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;

public class TelephonyInformationActivity extends Activity {

    private static String TAG = TelephonyInformationActivity.class.toString();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        String phoneNumber = telephonyManager.getLine1Number();
        String carrier = telephonyManager.getNetworkOperatorName();
        int dataState = telephonyManager.getDataState();
        String countryIso = telephonyManager.getNetworkCountryIso();
        String simSerialNumber = telephonyManager.getSimSerialNumber();

        Log.i(TAG, "phoneNumber : " + phoneNumber);
        Log.i(TAG, "carrier : " + carrier);
        Log.i(TAG, "dataState : " + dataState);
        Log.i(TAG, "countryIso : " + countryIso);
        Log.i(TAG, "simSerialNumber : " + simSerialNumber);
    }
}