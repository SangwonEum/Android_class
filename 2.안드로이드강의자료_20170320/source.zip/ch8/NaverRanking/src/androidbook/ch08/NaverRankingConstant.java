package androidbook.ch08;

public class NaverRankingConstant {
    
    public static final String NAVER_OPEN_API_URL = "http://openapi.naver.com/search?key=f5e0e9e35bba47b9ddc09f9f5fb23219&target=rank&query=nexearch";
    public static final String MESSAGE_NAVER_DATA_RECEIVED = "androidbook.ch08.naverRanking";
    public static final int DATA_INTERVAL = 10000;
    
}