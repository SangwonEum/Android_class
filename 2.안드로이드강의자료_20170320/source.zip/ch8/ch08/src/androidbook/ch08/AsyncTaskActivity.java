package androidbook.ch08;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

public class AsyncTaskActivity extends Activity {

    private ProgressBar mProgressBar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.asynctask);
        mProgressBar = (ProgressBar) findViewById(R.id.btnProgressBar);
    }

    public void onClick(View view) {
        new BackgroundTask().execute();
    }

    private class BackgroundTask extends AsyncTask<String, Integer, Long> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(AsyncTaskActivity.this, "BackgroundTask 시작전",
                    Toast.LENGTH_SHORT).show();
        }

        @Override
        protected Long doInBackground(String... datas) {

            long total = 0;
            for (int i = 0; i < 100; i++) {
                try {
                    Thread.sleep(100);
                } catch (Exception e) {
                }

                publishProgress(i);
                total = i;
            }

            return total;
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            mProgressBar.setProgress(progress[0]);
        }

        @Override
        protected void onPostExecute(Long result) {
            Toast.makeText(AsyncTaskActivity.this, "BackgroundTask 종료됨",
                    Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }
}