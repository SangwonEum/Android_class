package androidbook.ch12;

import androidbook.ch12.R;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends ListActivity {
    private String[] MENU_STRINGS = { "Simple Camera", "Audio Play", "Audio Record", "Video", "Speech Recognition" };
    private Class<?>[] MENU_CLASSES = { SimpleCameraActivity.class, AudioActivity.class, AudioRecordActivity.class, VideoActivity.class, SpeechActivity.class };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, MENU_STRINGS);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        startActivity(new Intent(this, MENU_CLASSES[position]));
    }
}
