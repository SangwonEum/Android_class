package androidbook.ch12;

import java.io.IOException;
import java.util.ArrayList;

import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import androidbook.ch12.R;

public class AudioActivity extends ListActivity {
    private static final int REQUEST_RECORD_AUDIO = 100;
    private ArrayList<FileItem> mAudioList;
    private MediaPlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.audio);
        setTitle("ch12 / Audio Play");

        mAudioList = loadAudioFiles();
        MediaListAdapter adapter = new MediaListAdapter(this, android.R.layout.simple_list_item_1, mAudioList);
        setListAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        stopAudio();
        super.onDestroy();
    }

    private ArrayList<FileItem> loadAudioFiles() {
        ArrayList<FileItem> items = new ArrayList<FileItem>();

        String[] proj = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATA };
        Cursor cursor = managedQuery(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, null, null, null);

        int indexName = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
        int indexData = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);

        if (cursor.moveToFirst()) {
            do {
                items.add(new FileItem(cursor.getString(indexName), cursor.getString(indexData)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        stopAudio();
        String filepath = mAudioList.get(position).getFilepath();

        try {
            playAudio(filepath);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void playAudio(String filepath) throws IllegalArgumentException, IllegalStateException, IOException {
        mPlayer = new MediaPlayer();
        mPlayer.setDataSource(filepath);
        mPlayer.prepare();
        mPlayer.start();
    }

    private void stopAudio() {
        if (mPlayer != null) {
            mPlayer.reset();
            mPlayer.release();
            mPlayer = null;
        }
    }

    public void onClickPause(View v) {
        if (mPlayer != null) {
            if (mPlayer.isPlaying()) {
                mPlayer.pause();
                Toast.makeText(this, "Pause", Toast.LENGTH_SHORT).show();
            } else {
                mPlayer.start();
                Toast.makeText(this, "Resume", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onClickStop(View v) {
        stopAudio();
        Toast.makeText(this, "Stop", Toast.LENGTH_SHORT).show();
    }
}
