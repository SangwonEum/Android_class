package androidbook.ch12;

import java.util.ArrayList;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ListView;
import android.widget.VideoView;
import androidbook.ch12.R;

public class VideoActivity extends ListActivity {
    private ArrayList<FileItem> mVideoList;
    private VideoView mVideoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video);
        setTitle("ch12 / Video");

        mVideoView = (VideoView) findViewById(R.id.videoView);
        mVideoList = loadVideoFiles();
        MediaListAdapter adapter = new MediaListAdapter(this, android.R.layout.simple_list_item_1, mVideoList);
        setListAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        stopVideo();
        super.onDestroy();
    }

    private ArrayList<FileItem> loadVideoFiles() {
        ArrayList<FileItem> items = new ArrayList<FileItem>();

        String[] proj = { MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATA };
        Cursor cursor = managedQuery(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null, null);

        int indexName = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME);
        int indexData = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);

        if (cursor.moveToFirst()) {
            do {
                items.add(new FileItem(cursor.getString(indexName), cursor.getString(indexData)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        stopVideo();
        String filepath = mVideoList.get(position).getFilepath();

        playVideo(filepath);
    }

    private void playVideo(String filepath) {
        mVideoView.requestFocus();
        mVideoView.setVideoPath(filepath);
        mVideoView.start();
    }

    private void stopVideo() {
        if (mVideoView.isPlaying())
            mVideoView.pause();
    }
}
