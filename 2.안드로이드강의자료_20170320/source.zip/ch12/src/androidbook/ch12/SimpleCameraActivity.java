package androidbook.ch12;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import androidbook.ch12.R;

public class SimpleCameraActivity extends Activity {
    private static final int SIMPLE_IMAGE_CAPTURE_REQUEST = 1;
    private static final int SIMPLE_VIDEO_CAPTURE_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.simple_take_picture);
        setTitle("ch12 / Simple Camera");
    }

    public void onClickImageCapture(View v) {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        File file = new File(Environment.getExternalStorageDirectory(), "image.jpg");
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
        startActivityForResult(intent, SIMPLE_IMAGE_CAPTURE_REQUEST);
    }

    public void onClickVideoCapture(View v) {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE);
        File file = new File(Environment.getExternalStorageDirectory(), "video.mp4");
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
        startActivityForResult(intent, SIMPLE_VIDEO_CAPTURE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

//        switch (requestCode) {
//        case SIMPLE_IMAGE_CAPTURE_REQUEST:
//            if (resultCode == Activity.RESULT_OK) {
//                //Bitmap picture = (Bitmap) data.getExtras().get("data");
//            }
//            break;
//        case SIMPLE_VIDEO_CAPTURE_REQUEST:
//            if (resultCode == Activity.RESULT_OK) {
//                Log.d("SimpleTakePictureActivity", "Capture Video Successed");
//            }
//            break;
//        }

        switch (requestCode) {
        case SIMPLE_IMAGE_CAPTURE_REQUEST:
            if (resultCode == Activity.RESULT_OK) {
                if (data == null) {
                    // do something with a stored image.
                }
            }
            break;
        case SIMPLE_VIDEO_CAPTURE_REQUEST:
            if (resultCode == Activity.RESULT_OK) {
                if (data == null) {
                    // do something with a stored video.
                }
            }
            break;
        }
    }
}
