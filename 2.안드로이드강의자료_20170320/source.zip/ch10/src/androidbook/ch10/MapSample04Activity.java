package androidbook.ch10;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class MapSample04Activity extends MapActivity {
    
    private Drawable mIconPizza;
    private List<Overlay> mMapOverlays;
    private MapView mapView;
    private MapController mapController;
    private PizzaItemizedOverlay itemizedOverlay;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mapview);
        
        double latitude = 37.527111;
        double longitude = 127.02844;
        GeoPoint point = new GeoPoint((int)(latitude*1E6), (int)(longitude*1E6));
        
        mapView = (MapView)findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        mapController = mapView.getController();
        mapController.animateTo(point);
        mapController.setZoom(19);
        
        mMapOverlays = mapView.getOverlays();
        mIconPizza = this.getResources().getDrawable(R.drawable.icon_pizza);
        itemizedOverlay = new PizzaItemizedOverlay(mIconPizza);
        
        OverlayItem overlayitem = new OverlayItem(point, "", "");
        itemizedOverlay.addItem(overlayitem);
        
        mMapOverlays.add(itemizedOverlay);
    }
    
    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }
}