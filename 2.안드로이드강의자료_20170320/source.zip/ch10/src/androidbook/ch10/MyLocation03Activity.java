package androidbook.ch10;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MyLocation03Activity extends Activity {
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mylocation3);
    }
    
    public void geocoder(View view)
    {
        double latitude = 37.527111;
        double longitude = 127.02844;
        
        Locale.setDefault(Locale.KOREA);
        Geocoder geocoder = new Geocoder(getApplicationContext());
        try {
            List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 3);
            
            for(Address address : addressList)
            {
                String countryName = address.getCountryName();
                String placeName = address.getLocality();
                
                String message = String.format("[%s][%s]",countryName,placeName);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}