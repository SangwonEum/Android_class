package androidbook.ch03;

import android.app.Activity;
import android.os.Bundle;


public class SampleActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sampleactivity_layout);
    }
}

