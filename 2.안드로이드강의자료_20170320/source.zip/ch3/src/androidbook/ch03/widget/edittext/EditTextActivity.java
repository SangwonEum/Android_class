package androidbook.ch03.widget.edittext;

import android.app.Activity;
import android.os.Bundle;
import androidbook.ch03.R;

public class EditTextActivity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edittext);
    }
}
