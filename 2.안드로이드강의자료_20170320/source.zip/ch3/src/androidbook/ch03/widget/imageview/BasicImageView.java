package androidbook.ch03.widget.imageview;

import android.app.Activity;
import android.os.Bundle;
import androidbook.ch03.R;

public class BasicImageView extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basic_imageview);
    }
}
