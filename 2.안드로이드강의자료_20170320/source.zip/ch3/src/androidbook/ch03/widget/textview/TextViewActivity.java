package androidbook.ch03.widget.textview;

import android.app.Activity;
import android.os.Bundle;
import androidbook.ch03.R;

public class TextViewActivity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.textview);
    }
}
