package androidbook.ch03.layout.relativelayout;

import android.app.Activity;
import android.os.Bundle;
import androidbook.ch03.R;

public class BasicRelativeLayout extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basic_relativelayout);
    }
}
