package androidbook.ch03.layout.linearlayout;

import android.app.Activity;
import android.os.Bundle;
import androidbook.ch03.R;

public class WeightLinearLayout extends Activity{
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_linearlayout);
    }
}
