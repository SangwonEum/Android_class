package androidbook.ch07;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class NotificationSample01 extends Activity implements OnClickListener {

    private final static int MESSAGE_ID = 12345;
    private Button mNofityButton;
    private Button mCancelButton;
    private NotificationManager mNotificationManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        mNofityButton = (Button) findViewById(R.id.nofity);
        mNofityButton.setOnClickListener(this);

        mCancelButton = (Button) findViewById(R.id.cancel);
        mCancelButton.setOnClickListener(this);
    }

    private void nofity() {
        String ticker = "티커메세지. 노티피케이션 테스트입니다. 내용이 길어지면 애니메이션으로 다음 내용으로 이동합니다. ";
        String title = "제목";
        String text = "내용. 노티피케이션 테스트입니다.";

        Intent intent = new Intent(this, NotificationActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                NotificationSample01.this, 0, intent, 0);
        Notification notification = new Notification(
                android.R.drawable.ic_input_add, ticker,
                System.currentTimeMillis());
        notification.setLatestEventInfo(this, title, text, pendingIntent);

        mNotificationManager.notify(MESSAGE_ID, notification);
        Toast.makeText(this, "Notification notify.", Toast.LENGTH_SHORT).show();
    }

    private void nofityCancel() {
        mNotificationManager.cancel(MESSAGE_ID);
        Toast.makeText(this, "Notification cancel.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.nofity:
            nofity();
            break;
        case R.id.cancel:
            nofityCancel();
            break;
        }
    }
}