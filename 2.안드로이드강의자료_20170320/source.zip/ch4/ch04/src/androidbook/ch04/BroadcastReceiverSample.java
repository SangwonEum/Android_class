package androidbook.ch04;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class BroadcastReceiverSample extends BroadcastReceiver {
    public static final String ACTION = "androidbook.ch04.action.BROADCAST_TEST";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(ACTION)) {
            Toast.makeText(context, "Broadcast Test", Toast.LENGTH_SHORT).show();
        }
    }
}
